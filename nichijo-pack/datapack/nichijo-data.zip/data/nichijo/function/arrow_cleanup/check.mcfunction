schedule function nichijo:arrow_cleanup/check 5s replace
scoreboard players add @e[type=#minecraft:arrows,nbt={NoGravity:1b,inGround:0b}] nichijo_arrow 1
kill @e[type=#minecraft:arrows,scores={nichijo_arrow=6..}]
