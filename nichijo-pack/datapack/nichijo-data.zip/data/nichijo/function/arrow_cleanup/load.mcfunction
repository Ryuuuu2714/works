scoreboard objectives add nichijo_arrow dummy
schedule function nichijo:arrow_cleanup/check 5s replace
